#include <iostream>
using namespace std;

void bubbleSort(char arr[], int n)
{
    int i, j;
    char temp;
    for (i = 0; i < n - 1; i++) 
    {
        for (j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1]) 
            {
               temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int stringLength(char str[]) 
{
    int len = 0;
    while (str[len] != '\0') 
    {
        len++;
    }
    return len;
}

int anagrams(char str1[], char str2[]) 
{
    int len1 = stringLength(str1);
    int len2 = stringLength(str2);

    if (len1 != len2) {
        return 0;  
    }

    bubbleSort(str1, len1);
    bubbleSort(str2, len2);

    
    for (int i = 0; i < len1; i++) 
    {
        if (str1[i] != str2[i])
        {
            return 0;  
        }
    }
    return 1;  
}

int main() {
    char s1[] = "listen";
    char s2[] = "silent";

    if (areAnagrams(s1, s2)) {
        cout << "Anagrams"<<endl;
    } else {
        cout << "Not Anagrams"<<endl;
    }

    return 0;
}
