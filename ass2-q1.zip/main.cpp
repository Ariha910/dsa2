#include <iostream>
using namespace std;

int main()
{
   int n, item;
   cout << "Enter number of elements in array: ";
    cin >> n;

    int arr[n];

   
    cout << "Enter sorted elements: ";
    for (int i = 0; i < n; i++) 
    {
        cin >> arr[i];
    }

    cout << "Enter item to search: ";
    cin >> item;

    int start = 0, end = n - 1;

    while (start <= end) 
    {
        int mid = (start + end) / 2;

        if (arr[mid] == item) 
        {
            cout<<"element found at "<<mid;
            break;
           
        }
        else if (arr[mid] < item)
        {
            start = mid + 1; 
        }
        else if(arr[mid] > item) 
        {
            end = mid - 1; 
        }
        else
        {
            cout<<"element not found";
        }
    }
    return 0; 
}
