#include <iostream>
using namespace std;
int main() {
   
   int n;
    cout<<"enter no of elements in array"<<endl;
    cin >> n;
    int arr[n-1];
    cout<<"enter elements";
    for(int i=0;i<n-1;i++)
    {
        cin>>arr[i];
    }

    int start=0, end =n-2; 

    while (start <= end)
    {
        int mid = (start + end) / 2;

        if (arr[mid] == mid + 1)
        {
            start = mid + 1; 
        } else
        {
            end = mid - 1;
        }
    }

    cout << "Missing number: " << start + 1;
}
