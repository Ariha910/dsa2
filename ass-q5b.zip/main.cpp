#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter size of matrix (n x n): ";
    cin >> n;

    int lower[n-1], main[n], upper[n-1];

    
    cout << "Enter elements of lower diagonal: ";
    for (int i = 0; i < n-1; i++)
        cin >> lower[i];

    cout << "Enter  elements of main diagonal: ";
    for (int i = 0; i < n; i++)
        cin >> main[i];

    cout << "Enter elements of upper diagonal: ";
    for (int i = 0; i < n-1; i++)
        cin >> upper[i];

    cout << "\nTri-Diagonal Matrix:\n";
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++) 
        {
            if (i == j)  
            {
                cout << main[i] << " ";
            }
            else if (i == j+1) 
            {
                cout << lower[j] << " ";
            }
            else if (j == i+1)   
            {
                cout << upper[i] << " ";
            }
            else  
            {
                cout << 0 << " ";
            }
        }
        cout << endl;
    }

    return 0;
}
