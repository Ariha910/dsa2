#include <iostream>
using namespace std;

struct Triplet {
    int row, col, val;
};

int main() {
    int rows, cols, nz;  
    cout << "Enter rows, cols and number of non-zero elements: ";
    cin >> rows >> cols >> nz;

    Triplet mat[50], tp[50]; 

    cout << "Enter row, col, value for each non-zero element:"<<endl;
    for (int i = 0; i < nz; i++) 
    {
        cin >> mat[i].row >> mat[i].col >> mat[i].val;
    }

    for (int i = 0; i < nz; i++) 
    {
        tp[i].row = mat[i].col;
        tp[i].col = mat[i].row;
        tp[i].val = mat[i].val;
    }

    cout << "Original Matrix (Triplet form):"<<endl;
    cout << "Row Col Val"<<endl;
    for (int i = 0; i < nz; i++)
    {
        cout << mat[i].row << "   " << mat[i].col << "   " << mat[i].val << endl;
    }

    cout << "Transposed Matrix (Triplet form):"<<endl;
    cout << "Row Col Val"<<endl;
    for (int i = 0; i < nz; i++)
    {
        cout << tp[i].row << "   " << tp[i].col << "   " << tp[i].val << endl;
    }

    return 0;
}
