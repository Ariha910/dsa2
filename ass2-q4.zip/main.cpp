 #include <iostream>
  #include <cstring>
using namespace std;

 int main() 
 {
//     //4A CONCATENATED STRINGS
// //     char s1[100], s2[100];
// //     int i = 0, j = 0;

// //     cout << "Enter first string: ";
// //   cin.getline(s1, 100);

// //     cout << "Enter second string: ";
// //   cin.getline(s2, 100);

    
// //     while (s1[i] != '\0')
// //     {
// //         i++;
// //     }

// //     while (s2[j] != '\0')
// //     {
// //         s1[i] = s2[j];
// //         i++;
// //         j++;
// //     }

// //     s1[i] = '\0';

// //     cout << "Concatenated String: " << s1 << endl;



// // 4B REVERSE A STRING

//   char str[100];
//     int len = 0, i = 0;

//     cout << "Enter a string: ";
//     cin.getline(str, 100);

//     while (str[len] != '\0')
//     {
//         len++;
//     }

   
//     for (i = 0; i < len / 2; i++)
//     {
//         char temp = str[i];
//         str[i] = str[len - i - 1];
//         str[len - i - 1] = temp;
//     }

//     cout << "Reversed String: " << str << endl;




//4C DELETE VOWELS
//   char st[100], newst[100];
//     int i = 0, j = 0;

//     cout << "Enter a string: ";
//     cin.getline(st, 100);

//     while (st[i] != '\0')
//     {
//         char ch = st[i];
        
//         if (!(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
//               ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')) 
//         {
//             newst[j] = ch; 
//             j++;
//         }
//         i++;
//     }

//     newst[j] = '\0'; 

//     cout << "String without vowels: " << newst << endl;
   
   
   
   //4D SORT IN ALPHABETICAL ORDER
     
     
    //  int n;
    // cout << "Enter number of strings: ";
    // cin >> n;
    //  cin.ignore(); 
    // char str[50][100];  

    // cout << "Enter the strings:"<<endl;
    // for (int i = 0; i < n; i++)
    // {
    //     cin.getline(str[i], 100);
    // }

    
    // char temp[100];
    // for (int i = 0; i < n - 1; i++) 
    // {
    //     for (int j = i + 1; j < n; j++) 
    //     {
    //         if (strcmp(str[i], str[j]) > 0) 
    //         { 
                
    //             strcpy(temp, str[i]);
    //             strcpy(str[i], str[j]);
    //             strcpy(str[j], temp);
    //         }
    //     }
    // }

    // cout << "Strings in alphabetical order "<<endl;
    // for (int i = 0; i < n; i++) 
    // {
    //     cout << str[i] << endl;
    // }
  
  
  
  //UPPERCASE TO LOWERCASE
 char str[100];
    cout << "Enter a string: ";
    cin.getline(str, 100);

    for (int i = 0; str[i] != '\0'; i++)
    {
        if (str[i] >= 'A' && str[i] <= 'Z') 
        {
            str[i] = str[i] + 32;
        } 
        else if (str[i] >= 'a' && str[i] <= 'z')
        {

            str[i] = str[i] - 32;
        }
    }

    cout << "Toggled string: " << str << endl;
    return 0;
}