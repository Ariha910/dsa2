#include <iostream>
using namespace std;
int main() {
   
   int n;
    cout<<"enter no of elements in array"<<endl;
    cin >> n;
    int arr[n-1];
    cout<<"enter elements";
    for(int i=0;i<n-1;i++)
    {
        cin>>arr[i];
    }
    int m;
    for (int i = 0; i < n-1; i++) {
        if (arr[i] != i + 1) {
           m = i + 1;
            break;
        }
    }

    cout << "Missing number is: " << m << endl;
    return 0;
}