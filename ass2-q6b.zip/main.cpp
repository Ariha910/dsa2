#include <iostream>
using namespace std;

struct Triplet
{
    int row, col, val;
};

int main() {
    int n1, n2;
    Triplet A[50], B[50], C[100];  

    cout << "Enter number of non-zero elements in first matrix: ";
    cin >> n1;
    cout << "Enter row col val for each non-zero element:"<<endl;
    for (int i = 0; i < n1; i++) {
        cin >> A[i].row >> A[i].col >> A[i].val;
    }

    cout << "Enter number of non-zero elements in second matrix: ";
    cin >> n2;
    cout << "Enter row col val for each non-zero element:"<<endl;
    for (int i = 0; i < n2; i++) {
        cin >> B[i].row >> B[i].col >> B[i].val;
    }

    int i = 0, j = 0, k = 0;

    
    while (i < n1 && j < n2) 
    {
        if (A[i].row == B[j].row && A[i].col == B[j].col)
        {
            int sum = A[i].val + B[j].val;
            if (sum != 0) 
            {
                C[k].row = A[i].row;
                C[k].col = A[i].col;
                C[k].val = sum;
                k++;
            }
            i++; j++;
        }
         else if (A[i].row < B[j].row || (A[i].row == B[j].row && A[i].col < B[j].col))
        {
            C[k++] = A[i++];
        }
        else 
        {
            C[k++] = B[j++];
        }
    }

  
    while (i < n1) 
    {
      C[k++] = A[i++];
    }
    while (j < n2) 
    {
      C[k++] = B[j++];
    }

    cout << "Result after addition (Triplet form):"<<endl;
    cout << "Row Col Val"<<endl;
    for (int m = 0; m < k; m++) 
    {
        cout << C[m].row << "   " << C[m].col << "   " << C[m].val << endl;
    }

    return 0;
}
